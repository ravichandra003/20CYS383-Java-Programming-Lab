package com.amrita.jpl.cys21044.p2.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author ravi
 * @version 1.0
 */
abstract class QuizGame {
    abstract void startGame();

    abstract void askQuestion();

    abstract void evaluateAnswer(String answer);
}

interface QuizGameListener {
    void onQuestionAsked(String question);

    void onAnswerEvaluated(boolean isCorrect);

    void onGameFinished(String winner);
}

class QuizGameServer extends QuizGame {
    private int port;
    private List<QuizGameClientHandler> clientHandlers;
    private List<String> questions;
    private List<String> answers;
    private String winner;

    /**
     * @param port - port number
     */
    public QuizGameServer(int port) {
        this.port = port;
        clientHandlers = new ArrayList<>();
        questions = new ArrayList<>();
        answers = new ArrayList<>();
        initializeQuestionsAndAnswers();

    }

    private void initializeQuestionsAndAnswers() {
        questions.add("What is the capital of india?");
        questions.add("What is the largest continent?");
        questions.add("What is the captial of andhra pradesh?");

        answers.add("delih");
        answers.add("asia");
        answers.add("vishkapatnam");
    }


    @Override
    void startGame() {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Quiz started on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                QuizGameClientHandler clientHandler = new QuizGameClientHandler(clientSocket);
                clientHandlers.add(clientHandler);
                clientHandler.start();
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    void askQuestion() {
        Random random = new Random();
        int questionIndex = random.nextInt(questions.size());
        String question = questions.get(questionIndex);

        for (QuizGameClientHandler clientHandler : clientHandlers) {
            clientHandler.askQuestion(question);
        }
    }

    @Override
    void evaluateAnswer(String answer) {
        boolean isCorrect = answers.contains(answer);

        for (QuizGameClientHandler clientHandler : clientHandlers) {
            clientHandler.evaluateAnswer(isCorrect);
        }
    }

    private class QuizGameClientHandler extends Thread {
        private Socket clientSocket;
        private BufferedReader reader;
        private PrintWriter writer;

        /**
         *
         * @param clientSocket -socket of client
         */
        public QuizGameClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                writer = new PrintWriter(clientSocket.getOutputStream(), true);


                startGame();

            } catch (IOException e) {
                System.out.println("Error: " + e.getMessage());
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                    if (writer != null) {
                        writer.close();
                    }
                    clientSocket.close();
                } catch (IOException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }

        public void askQuestion(String question) {
            writer.println("QUESTION:" + question);
        }

        public void evaluateAnswer(boolean isCorrect) {
            if (isCorrect) {
                writer.println("CORRECT");
            } else {
                writer.println("INCORRECT");
            }
        }
    }
}

class QuizGameClient implements QuizGameListener {
    private String serverAddress;
    private int port;

    /**
     *
     * @param serverAddress - address of the server
     * @param port -port number
     */

    public QuizGameClient(String serverAddress, int port) {
        this.serverAddress = serverAddress;
        this.port = port;
    }

    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);

    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Your answer is correct!");
        } else {
            System.out.println("Your answer is incorrect!");
        }

    }

    @Override
    public void onGameFinished(String winner) {
        System.out.println("The winner of the quiz game is: " + winner);

    }

    public void startGame() {
        try (Socket socket = new Socket(serverAddress, port);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            System.out.println("Connected to Quiz Game server");

            while (true) {
                String message = reader.readLine();
                if (message.startsWith("QUESTION:")) {
                    String question = message.substring("QUESTION:".length());
                    onQuestionAsked(question);
                } else if (message.equals("CORRECT")) {
                    onAnswerEvaluated(true);
                } else if (message.equals("INCORRECT")) {
                    onAnswerEvaluated(false);
                } else if (message.startsWith("WINNER:")) {
                    String winner = message.substring("WINNER:".length());
                    onGameFinished(winner);
                    break;
                }
            }

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

public class Serverside {
    public static void main(String[] args) {
        int port = 21044;

        QuizGameServer server = new QuizGameServer(port);
        server.startGame();

        String serverAddress = "localhost";
        QuizGameClient client = new QuizGameClient(serverAddress, port);
        client.startGame();
    }
}
