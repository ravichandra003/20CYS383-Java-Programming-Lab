package com.amrita.jpl.cys21044.p2.client;
/**
* @author ravi
 * @version 1.0
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

interface QuizGameListener {
    void onQuestionAsked(String question);

    void onAnswerEvaluated(boolean isCorrect);

    void onGameWinnerDeclared(String winner);

}

class QuizGameClient implements QuizGameListener {
    private Socket serverSocket;
    private BufferedReader reader;

    /**
     *
     * @param serverAddress -serveraddress
     * @param port - portnumber
     */
    public void startGame(String serverAddress, int port) {
        try {
            serverSocket = new Socket(serverAddress, port);
            reader = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));


            setListener(this);

            String message;
            while ((message = reader.readLine()) != null) {
                handleMessage(message);
            }

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
                if (serverSocket != null) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

    }

    private void handleMessage(String message) {
        if (message.startsWith("QUESTION:")) {
            String question = message.substring(9);
            onQuestionAsked(question);
        } else if (message.equals("CORRECT")) {
            onAnswerEvaluated(true);
        } else if (message.equals("INCORRECT")) {
            onAnswerEvaluated(false);
        } else if (message.startsWith("WINNER:")) {
            String winner = message.substring(7);
            onGameWinnerDeclared(winner);

        }

    }

    public void setListener(QuizGameListener listener) {

    }

    @Override
    public void onQuestionAsked(String question) {
        System.out.println("The question is: " + question);
    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        String result = isCorrect ? "Correct" : "Incorrect";
        System.out.println("Your answer is evaluated as: " + result);
    }

    @Override
    public void onGameWinnerDeclared(String winner) {

        System.out.println("The winner of the Quiz Game is: " + winner);


    }
}

public class Clientside{
    public static void main(String[] args) {
        String serverAddress = "localhost";
        int port = 21044;
        QuizGameClient client = new QuizGameClient();
        client.startGame(serverAddress, port);
    }
}
